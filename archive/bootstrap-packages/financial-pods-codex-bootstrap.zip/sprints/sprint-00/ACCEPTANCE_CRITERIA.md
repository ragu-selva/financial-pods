# Sprint 00 Acceptance Criteria

Mark items complete only with evidence in `REVIEW.md`.

- [ ] Existing finalized artifacts are unchanged.
- [ ] `apps/web` starts and renders a minimal accessible placeholder without product features.
- [ ] TypeScript strict, ESLint, Prettier, Vitest, and Playwright configurations execute.
- [ ] The production web build succeeds.
- [ ] `apps/api` runs on Python 3.12+ with FastAPI and Pydantic.
- [ ] `GET /health` returns HTTP 200 with a documented typed payload and automated test.
- [ ] Ruff, mypy, and pytest execute successfully.
- [ ] PostgreSQL with pgvector and Redis report healthy locally.
- [ ] Docker orchestration starts web, API, PostgreSQL/pgvector, and Redis with health checks.
- [ ] `.env.example` contains no secrets; local secret/state files are ignored.
- [ ] The task runner covers setup, dev, lint, format-check, typecheck, test, build, e2e, up, down, and logs (or equivalents).
- [ ] Unit/integration locations are wired; regulatory and AI-eval suites remain placeholders.
- [ ] CI runs install, lint, typecheck, test, and build without production secrets.
- [ ] Onboarding documents prerequisites, startup, verification, and recovery.
- [ ] `make lint`, `make typecheck`, `make test`, and `make build` (or equivalents) pass.
- [ ] No FinBank, corporate-exposure, regulatory-calculation, lesson, or tutor feature was implemented.
