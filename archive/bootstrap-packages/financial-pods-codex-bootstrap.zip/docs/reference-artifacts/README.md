# Reference Artifacts

Copy existing finalized DOCX, PPTX, HTML, images, and similar artifacts here without modifying their contents. Preserve filenames and record source/checksum metadata. Treat this directory as read-only unless the owner explicitly authorizes a change.

No artifacts were copied automatically because the current inventory contained no such files.
